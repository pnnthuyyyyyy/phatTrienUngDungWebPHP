-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 25, 2023 at 04:45 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `flashtel`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `CompID` int(50) NOT NULL auto_increment,
  `CompName` varchar(50) collate utf8_danish_ci NOT NULL,
  `CompAddress` varchar(100) collate utf8_danish_ci NOT NULL,
  `CompPhone` varchar(11) collate utf8_danish_ci default NULL,
  `Email` varchar(50) collate utf8_danish_ci default NULL,
  PRIMARY KEY  (`CompID`),
  UNIQUE KEY `CompName` (`CompName`,`CompAddress`,`CompPhone`,`Email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_danish_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`CompID`, `CompName`, `CompAddress`, `CompPhone`, `Email`) VALUES
(1, 'Iphone', '12 Nguyễn Văn Bảo phường 15 Gò Vấp', '0123456789', 'iphone@gmail.com'),
(5, 'Mobell', '234 Meo meo, Bình Dương', '1112223334', 'mobell@gmail.com'),
(4, 'Oppo', '444 Lê đức thọ GV', '8889997776', 'oppo@gmail.com'),
(2, 'Samsung', '1 Nguyễn Thái Sơn, phường 5, Gò Vấp', '0909333666', 'samsung123@gmail.com'),
(3, 'Xiaomi', '123 Nguyễn Văn Lượng GV', '0909111333', 'xiaomi@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProdID` int(11) NOT NULL auto_increment,
  `ProdName` varchar(50) NOT NULL,
  `ProdPrice` double NOT NULL,
  `ProdImage` varchar(50) NOT NULL,
  `ProdDescription` varchar(50) default NULL,
  `CompID` int(11) NOT NULL,
  PRIMARY KEY  (`ProdID`),
  UNIQUE KEY `ProdName` (`ProdName`,`ProdPrice`,`ProdImage`,`ProdDescription`),
  KEY `CompID` (`CompID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProdID`, `ProdName`, `ProdPrice`, `ProdImage`, `ProdDescription`, `CompID`) VALUES
(1, 'Iphone 11 đen', 11000000, 'iphone-11-den.jpg', '', 1),
(2, 'Iphone 12 đen', 13999000, 'iphone-12-den.jpg', '', 1),
(3, 'Iphone 13 starlight', 20490000, 'iphone-13-starlight.jpg', '', 1),
(4, 'Iphone 14 plus đen thui ', 23999000, 'iPhone-14-plus-den.jpg', '', 1),
(5, 'Iphone 14 pro vàng ', 25100000, 'iPhone-14-pro-vang.jpg', NULL, 1),
(6, 'Sasung galaxy M53 Nâu', 50000000, 'samsung-galaxy-m53-nau.jpg', NULL, 2),
(7, 'Samsung galaxy S23', 10900000, 'samsung-galaxy-s23.jpg', NULL, 2),
(8, 'Samsung galaxy s23 ltra', 22000000, 'samsung-galaxy-s23-ultra.jpg', NULL, 2),
(9, 'Samsung galaxy z flip4 5G 128gb Tím', 40900000, 'samsung-galaxy-z-flip4-5g-128gb-thumb-tim.jpg', NULL, 2),
(10, 'Samsung galaxy Zfold4', 44000000, 'samsung-galaxy-z-fold4-kem-256gb.jpg', '', 2),
(11, 'Xiaomi 13 đen', 12000000, 'xiaomi-13-thumb-den.jpg', NULL, 3),
(12, 'Xiaomi Redmi 10A', 5490000, 'xiaomi-redmi-10a.jpg', '', 3),
(13, 'Xiaomi Redmi 12C xám', 13000000, 'xiaomi-redmi-12c-grey.jpg', '', 3),
(14, 'Xiaomi Redmi note 11 pro trắng', 3500000, 'xiaomi-redmi-note-11-pro-trang.jpg', NULL, 3),
(15, 'xiaomi redmi note 12 4G Mono đen', 9190000, 'xiaomi-redmi-note-12-4g-mono-den.jpg', NULL, 3),
(16, 'OPPO A16K đen thui', 11000000, 'OPPO-a16k-den-nhan-thumb.jpg', NULL, 4),
(17, 'Oppo A95 4G bạc', 17000000, 'oppo-a95-4g-bac-2.jpg', NULL, 4),
(18, 'Oppo N2 flip đen ', 23000000, 'oppo-n2-flip-den.jpg', NULL, 4),
(19, 'Oppo Reno 7z 5G', 19990000, 'oppo-reno7-z-5g-thumb.jpg', '', 4),
(20, 'Oppo reno8 pro xanh ngọc', 11990999, 'oppo-reno8-pro-thumb-xanh.jpg', '', 4),
(21, 'Mobell f209 Đen', 630000, 'mobell-f209-den.jpg', NULL, 5),
(22, 'Mobell F309 trắng', 760000, 'mobell-f309-trang.jpg', NULL, 5),
(23, 'Mobell M239 đỏ', 3900000, 'mobell-m239-do.jpg', '', 5),
(24, 'Mobell M539 đỏ ', 730000, 'mobell-m539-do.jpg', NULL, 5),
(25, 'Mobell rock 4 xanh dương', 810000, 'mobell-rock-4-xanh-duong-thumb.jpg', NULL, 5),
(26, 'iphone 14 đỏ ', 24000000, 'iPhone-14-do.jpg', '', 1),
(27, 'Samsung galaxy A04 ', 3500000, 'samsung-galaxy-a04.jpg', '', 2),
(35, 'Iphone 12 hồng', 20160000, 'iphone-13-pink.jpg', '', 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`CompID`) REFERENCES `company` (`CompID`) ON DELETE CASCADE ON UPDATE CASCADE;
